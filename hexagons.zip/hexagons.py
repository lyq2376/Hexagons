"""
    file: hexagons.py
    descriptionL To draw a sequence of hexagons twice in order
    in order to create a specific pattern
    language: python 3
    author: Lindy Quach
    section: 3 (Group A)
"""

# imports the turtle module which draws pictures on a canvas window

import turtle

# definitions of functions and procedures


def init():
    """Initialize turtle
    :precondition: Pen is down
    :precondition: Turtle is facing east
    :precondition: Pensize is 2
    :postcondition: Turtle is initialized
    """
    turtle.down()
    turtle.title('hexagons')
    turtle.pensize(2)


def draw_side():
    """
        Make the turtle draw 60 pixels for a side of a hexagon
        :precondition: Pen is down
        :precondition: Pensize is 2
        :precondition: Turtle is facing east in which the first
        side of the first hexagon will be drawn.
        :postcondition: Turtle will turn to the left 60 degrees and
        will draw the next side of the hexagon when the method
        is called
    """
    turtle.forward(60)
    turtle.left(60)


def draw_hexagons():
    """
        Make the turtle draw a hexagon 60 pixels on each side
        :precondition: Pen is down
        :precondition: Turtle is facing the direction in which the first
        side will be drawn
        :postcondition: Turtle's state (location, direction, pen position) is
        the same as when this function started.
        :postcondition: Turtle will turn to the right 60 degrees
        to draw the next hexagon
    """
    draw_side()
    draw_side()
    draw_side()
    draw_side()
    draw_side()
    draw_side()
    turtle.forward(60)
    turtle.right(60)


def draw_diagram():
    """
        Make the turtle draw an image of 6 hexagons
        :precondition: Pen is down
        :precondition: The canvas is blank
        :postcondition: Turtle will turn 60 degrees to the right
        once the function is done
        and will draw the same 3D image
    """
    draw_hexagons()
    draw_hexagons()
    draw_hexagons()
    draw_hexagons()
    draw_hexagons()
    draw_hexagons()


def main():
    """
        :precondition: Pen is down
        :precondition: Canvas is blank
        :precondition: After the first diagram() is done, the turtle will turn
        to the right 60 degrees and will call the same function
        :postcondition: A 3D image of 12 hexagons
         will be drawn be the turtle when the function
        is done
    """
    init()
    draw_diagram()
    turtle.right(60)
    draw_diagram()
    print('click on the "X" button on the window title bar')
    turtle.done()


if __name__ == "__main__":
    main()
